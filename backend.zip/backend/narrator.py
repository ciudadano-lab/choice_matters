from __future__ import annotations

from typing import Any

from location_lookup import resolve_location_id
from simulation_engine import StructuredAction, SimulationResult
from world_state import settlement_tier


def _find_location_name(world_state: dict[str, Any], location_id: str) -> str:
    resolved_id = resolve_location_id(world_state, location_id)
    locations = world_state.get("locations", [])
    if isinstance(locations, dict):
        location = locations.get(resolved_id)
        if isinstance(location, dict):
            return location.get("name", location_id)
    location_values = (
        locations.values() if isinstance(locations, dict)
        else locations if isinstance(locations, list)
        else []
    )
    for location in location_values:
        if isinstance(location, dict) and location.get("id") == resolved_id:
            return location.get("name", location_id)
    return location_id


def _format_resource_changes(changes: dict[str, int]) -> str | None:
    if not changes:
        return None
    parts = []
    for resource, delta in sorted(changes.items()):
        if delta == 0:
            continue
        sign = "+" if delta > 0 else ""
        parts.append(f"{sign}{delta} {resource}")
    if not parts:
        return None
    return ", ".join(parts)


def _format_player_status_changes(changes: list[dict[str, Any]]) -> list[str]:
    phrases: list[str] = []
    for change in changes:
        player_id = change.get("playerId")
        for key, value in change.items():
            if key == "playerId":
                continue
            if key == "location":
                continue
            if isinstance(value, (int, float)):
                name = key.replace("_", " ")
                sign = "increases" if value > 0 else "decreases"
                phrases.append(f"{name.capitalize()} {sign} by {abs(int(value))}.")
            else:
                phrases.append(f"{key.capitalize()} is now {value}.")
    return phrases


def _summarize_world_events(events: list[dict[str, Any]]) -> list[str]:
    if not events:
        return []
    phrases: list[str] = []
    for event in events:
        event_type = event.get("type")
        if event_type == "travel":
            phrases.append("The move completes without incident.")
        elif event_type == "encounter":
            phrases.append("A possible encounter is now in play.")
        elif event_type == "search":
            phrases.append("The area has been scouted.")
        elif event_type == "gather":
            phrases.append("Supplies have been gathered.")
        elif event_type == "rest":
            phrases.append("You take a moment to recover.")
        elif event_type == "build":
            phrases.append("You devote time to construction.")
        elif event_type == "reinforce":
            phrases.append("Defenses have been strengthened.")
        else:
            phrases.append(f"An event of type '{event_type}' occurs.")
    return phrases


def narrate_simulation_result(
    previous_state: dict[str, Any],
    action: StructuredAction,
    result: SimulationResult,
    player_known_info: dict[str, Any] | None = None,
) -> str:
    lines: list[str] = []
    location_name = _find_location_name(previous_state, action.target)

    if result.rejected:
        return f"The action cannot be carried out: {result.rejectionReason or 'the claimed target is not known.'}"
    if result.physicallyImpossible:
        return result.impossibleReason or "Nothing happens; the claimed effect is not possible in this world."

    social_outcome = getattr(result, "socialOutcome", {}) or {}
    if social_outcome.get("reaction") and action.actionType in {"recruit", "negotiate", "trade"}:
        target_name = action.target.replace("npc_", "").replace("_", " ").title()
        reaction = social_outcome.get("reaction")
        if reaction == "accepted":
            lines.append(f"{target_name} accepts the offer.")
        elif reaction == "countered":
            lines.append(f"{target_name} counters the proposal.")
        else:
            lines.append(f"{target_name} declines the offer.")

    if action.actionType == "travel":
        lines.append(f"You travel toward {location_name}.")
    elif action.actionType == "search":
        lines.append(f"You search the area at {location_name}.")
    elif action.actionType == "gather":
        lines.append("You spend time gathering supplies.")
    elif action.actionType == "build":
        lines.append("You work on building and fortifying the site.")
    elif action.actionType == "reinforce":
        lines.append("You focus on reinforcing your position.")
    elif action.actionType == "rest":
        lines.append("You take a break to rest and recover.")
    elif action.actionType == "communicate":
        lines.append("You reach out to others and exchange messages.")
    elif action.actionType == "negotiate":
        lines.append("You attempt to negotiate with nearby survivors.")
    elif action.actionType == "attack":
        lines.append(f"You launch an attack on {location_name}.")
    elif action.actionType == "defend":
        lines.append("You prepare to defend your position.")
    elif action.actionType == "trade":
        lines.append("You conduct a trade to shift resources.")
    elif action.actionType == "recruit":
        lines.append("You try to recruit help from others.")
    elif action.actionType == "send_mission":
        lines.append("You send out a mission on your behalf.")
    elif action.actionType == "establish_settlement":
        settlements = result.updatedWorldState.get("settlements", [])
        target_location_id = resolve_location_id(
            result.updatedWorldState,
            action.target,
        ) or action.target
        settlement = next(
            (
                item for item in settlements
                if item.get("location") == target_location_id
            ),
            None,
        )
        if settlement is None:
            lines.append("You work to establish a new settlement.")
        else:
            population = int(settlement.get("population", 0))
            tier = settlement_tier(population)
            lines.append(
                f"You establish {settlement.get('name', location_name)} with "
                f"{population} residents (settlement tier {tier})."
            )
    else:
        lines.append(f"You perform {action.actionType}.")

    if result.timeConsumed:
        lines.append(f"This takes {result.timeConsumed} time unit{'s' if result.timeConsumed != 1 else ''}.")

    resource_text = _format_resource_changes(result.resourceChanges)
    if resource_text:
        lines.append(f"Resource change: {resource_text}.")

    status_phrases = _format_player_status_changes(result.playerStatusChanges)
    if status_phrases:
        lines.extend(status_phrases)

    if result.locationChanges:
        for change in result.locationChanges:
            loc_name = _find_location_name(previous_state, change.get("locationId", ""))
            if loc_name:
                lines.append(f"{loc_name} is now marked as {change.get('state', 'visited')}.")

    if result.informationDiscovered:
        for info in result.informationDiscovered:
            content = info.get("content")
            if content:
                lines.append(f"You discover: {content}")

    if result.encounterOccurred:
        lines.append("A hostile encounter occurs.")
    else:
        lines.append("You avoid a hostile encounter this time.")

    encounter_outcome = getattr(result, "encounterOutcome", None)
    if isinstance(encounter_outcome, dict):
        outcome_text = {
            "evaded": "The encounter is evaded.",
            "close_call": "The encounter ends in a close call.",
            "hurt": "The encounter leaves you hurt.",
            "serious": "The encounter causes serious harm.",
        }.get(encounter_outcome.get("outcome"), "The encounter is resolved.")
        lines.append(outcome_text)
        reasons = encounter_outcome.get("reasons", [])
        reason_text = [
            f"{'helps' if reason.get('effect') == 'helps' else 'hurts'}: "
            f"{reason.get('explanation')}"
            for reason in reasons
            if isinstance(reason, dict) and reason.get("explanation")
        ]
        if reason_text:
            lines.append("Encounter factors: " + "; ".join(reason_text))

    lines.extend(_summarize_world_events(result.worldEventsTriggered))

    if not lines:
        return "The action completes with no notable changes."
    return " ".join(lines)
